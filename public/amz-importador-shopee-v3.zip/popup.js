// popup.js - AMZ Importador Shopee v3.0

var SUPABASE_URL = "https://jibpvpqgplmahjhswiza.supabase.co/functions/v1/extensao-importar-produtos";
var PLATFORM_URL = "https://amzofertas.com.br/integracoes";

var produtosExtraidos = [];
var apiKeyAtual = null;

// ============================================
// INIT
// ============================================
document.addEventListener("DOMContentLoaded", function() {
  console.log("[AMZ] Popup carregado");

  chrome.storage.local.get(["amz_api_key", "amz_quantidade"], function(data) {
    if (data.amz_api_key) {
      apiKeyAtual = data.amz_api_key;
      mostrarTelaPrincipal();
      detectarPagina();
    } else {
      mostrarTelaConfig();
    }

    if (data.amz_quantidade) {
      var qtdEl = document.getElementById("quantidade");
      if (qtdEl) qtdEl.value = data.amz_quantidade;
    }
  });

  // Listeners - Tela de configuracao
  document.getElementById("btn-salvar-key").addEventListener("click", salvarApiKey);
  document.getElementById("link-integracoes").addEventListener("click", function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: PLATFORM_URL });
  });
  document.getElementById("api-key-input").addEventListener("keypress", function(e) {
    if (e.key === "Enter") salvarApiKey();
  });

  // Listeners - Tela principal
  document.getElementById("btn-extrair").addEventListener("click", extrairProdutos);
  document.getElementById("btn-enviar").addEventListener("click", enviarProdutos);
  document.getElementById("btn-trocar-key").addEventListener("click", trocarApiKey);
  document.getElementById("quantidade").addEventListener("change", function(e) {
    chrome.storage.local.set({ amz_quantidade: e.target.value });
  });
});

// ============================================
// GERENCIAMENTO DE TELAS
// ============================================
function mostrarTelaConfig() {
  document.getElementById("tela-config").classList.remove("hidden");
  document.getElementById("tela-principal").classList.add("hidden");
  setTimeout(function() { document.getElementById("api-key-input").focus(); }, 100);
}

function mostrarTelaPrincipal() {
  document.getElementById("tela-config").classList.add("hidden");
  document.getElementById("tela-principal").classList.remove("hidden");

  // Mostrar preview da chave (primeiros 16 chars)
  var preview = apiKeyAtual.substring(0, 16) + "...";
  document.getElementById("api-key-preview").textContent = preview;
}

// ============================================
// API KEY
// ============================================
function salvarApiKey() {
  var input = document.getElementById("api-key-input");
  var key = input.value.trim();

  if (!key) {
    alert("Digite sua API Key");
    return;
  }

  if (key.indexOf("amz_sk_") !== 0) {
    alert("Formato invalido. A chave deve comecar com 'amz_sk_'");
    return;
  }

  if (key.length < 30) {
    alert("Chave muito curta. Copie a chave completa da pagina de Integracoes.");
    return;
  }

  chrome.storage.local.set({ amz_api_key: key }, function() {
    apiKeyAtual = key;
    input.value = "";
    mostrarTelaPrincipal();
    detectarPagina();
    addLog("API Key salva com sucesso!");
  });
}

function trocarApiKey() {
  if (!confirm("Deseja remover a API Key atual e configurar uma nova?")) return;

  chrome.storage.local.remove("amz_api_key", function() {
    apiKeyAtual = null;
    produtosExtraidos = [];
    mostrarTelaConfig();
  });
}

// ============================================
// DETECCAO DE PAGINA
// ============================================
function detectarPagina() {
  var statusEl = document.getElementById("status-pagina");

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    var url = tab && tab.url ? tab.url : "";

    var isShopee = url.indexOf("shopee.com") !== -1 || url.indexOf("collshp.com") !== -1;

    if (!isShopee) {
      statusEl.textContent = "Abra uma pagina da Shopee para comecar";
      statusEl.className = "status warning";
      document.getElementById("btn-extrair").disabled = true;
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "detectar_tipo" }, function(response) {
      if (chrome.runtime.lastError) {
        statusEl.textContent = "Recarregue a pagina (F5) e abra novamente";
        statusEl.className = "status warning";
        document.getElementById("btn-extrair").disabled = true;
        return;
      }

      if (response && response.success) {
        var texto = "OK: " + response.nome;
        if (response.categoria) texto += " [" + response.categoria + "]";
        statusEl.textContent = texto;
        statusEl.className = "status success";
        document.getElementById("btn-extrair").disabled = false;

        addLog("Pagina: " + response.nome);
        if (response.categoria) addLog("Categoria: " + response.categoria);
      } else {
        statusEl.textContent = "Pagina nao suportada";
        statusEl.className = "status warning";
      }
    });
  });
}

// ============================================
// EXTRACAO
// ============================================
function extrairProdutos() {
  var btn = document.getElementById("btn-extrair");
  var quantidade = parseInt(document.getElementById("quantidade").value) || 20;

  btn.disabled = true;
  btn.textContent = "Extraindo...";
  addLog("Extraindo " + quantidade + " produtos...");

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];

    chrome.tabs.sendMessage(tab.id, { action: "extrair_produtos", quantidade: quantidade }, function(response) {
      btn.disabled = false;
      btn.textContent = "Extrair Produtos";

      if (chrome.runtime.lastError) {
        addLog("ERRO: " + chrome.runtime.lastError.message);
        return;
      }

      if (response && response.success && response.produtos && response.produtos.length > 0) {
        produtosExtraidos = response.produtos;

        var comPreco = 0;
        var comCategoria = 0;
        for (var i = 0; i < produtosExtraidos.length; i++) {
          if (produtosExtraidos[i].preco > 0) comPreco++;
          if (produtosExtraidos[i].categoria) comCategoria++;
        }

        addLog("OK: " + produtosExtraidos.length + " produtos extraidos!");
        addLog("Com preco: " + comPreco + " | Com categoria: " + comCategoria);

        document.getElementById("btn-enviar").disabled = false;
        document.getElementById("total-produtos").textContent =
          produtosExtraidos.length + " produtos prontos para envio";
      } else {
        addLog("Nenhum produto encontrado nesta pagina");
        document.getElementById("total-produtos").textContent = "Nenhum produto encontrado";
      }
    });
  });
}

// ============================================
// ENVIO EM LOTE PARA SUPABASE
// ============================================
function enviarProdutos() {
  if (produtosExtraidos.length === 0) {
    addLog("Extraia produtos primeiro!");
    return;
  }

  if (!apiKeyAtual) {
    addLog("ERRO: API Key nao configurada");
    mostrarTelaConfig();
    return;
  }

  var btn = document.getElementById("btn-enviar");
  btn.disabled = true;
  btn.textContent = "Enviando...";
  addLog("Enviando " + produtosExtraidos.length + " produtos em lote...");

  // Normalizar produtos para o formato esperado pela edge function
  var produtosPayload = [];
  for (var i = 0; i < produtosExtraidos.length; i++) {
    var p = produtosExtraidos[i];

    if (!p.link || p.link.indexOf("OBTER_VIA") !== -1) continue;

    produtosPayload.push({
      nome: p.nome,
      preco: typeof p.preco === "number" ? p.preco : 0,
      imagem_url: p.imagem || "",
      imagens: p.imagem ? [p.imagem] : [],
      link: p.link,
      descricao: p.descricao || null,
      categoria: p.categoria || null
    });
  }

  if (produtosPayload.length === 0) {
    btn.disabled = false;
    btn.textContent = "Enviar para AMZ";
    addLog("Nenhum produto valido para enviar");
    return;
  }

  var body = {
    marketplace: "shopee",
    produtos: produtosPayload
  };

  fetch(SUPABASE_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKeyAtual
    },
    body: JSON.stringify(body)
  })
  .then(function(response) {
    return response.json().then(function(data) {
      return { status: response.status, data: data };
    });
  })
  .then(function(result) {
    btn.disabled = false;
    btn.textContent = "Enviar para AMZ";

    if (result.status === 401) {
      addLog("ERRO: API Key invalida ou revogada");
      addLog("Vá em AMZ Ofertas > Integracoes e gere uma nova");
      document.getElementById("total-produtos").textContent = "Chave invalida";
      return;
    }

    if (result.status !== 200 || !result.data.success) {
      addLog("ERRO: " + (result.data.error || "Resposta invalida"));
      return;
    }

    var d = result.data;
    addLog("Concluido!");
    addLog("  Recebidos: " + d.total_recebidos);
    addLog("  Importados: " + d.total_importados);
    addLog("  Duplicados: " + d.total_duplicados);
    addLog("  Rejeitados: " + d.total_rejeitados);

    document.getElementById("total-produtos").textContent =
      d.total_importados + " produtos importados para AMZ!";

    produtosExtraidos = [];
    document.getElementById("btn-enviar").disabled = true;
  })
  .catch(function(err) {
    btn.disabled = false;
    btn.textContent = "Enviar para AMZ";
    addLog("ERRO de rede: " + err.message);
    addLog("Verifique sua conexao com a internet");
  });
}

// ============================================
// LOG
// ============================================
function addLog(texto) {
  var logEl = document.getElementById("log");
  if (!logEl) return;
  var now = new Date();
  var hours = String(now.getHours()).padStart(2, "0");
  var minutes = String(now.getMinutes()).padStart(2, "0");
  var seconds = String(now.getSeconds()).padStart(2, "0");
  var time = hours + ":" + minutes + ":" + seconds;
  logEl.innerHTML += "[" + time + "] " + texto + "\n";
  logEl.scrollTop = logEl.scrollHeight;
}
