// background.js - AMZ Importador Shopee v3.0

console.log("[AMZ] Background worker iniciado");

chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    console.log("[AMZ] Extensao instalada - primeira vez");
  }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log("[AMZ] Background msg:", request.action);
  sendResponse({ received: true });
  return true;
});
