// content.js - AMZ Importador Shopee v3.0

(function() {
  "use strict";

  console.log("[AMZ] Content script v3.0 carregado");

  // Affiliate ID dinamico: carregado de chrome.storage se o usuario configurou.
  // Se vazio, usa o link original da Shopee (funciona para seller/prestador, nao so afiliado).
  var AFFILIATE_ID = "";
  try {
    chrome.storage.local.get(["amz_affiliate_id"], function(data) {
      if (data && data.amz_affiliate_id) {
        AFFILIATE_ID = String(data.amz_affiliate_id).trim();
        console.log("[AMZ] Affiliate ID configurado");
      }
    });
  } catch (e) {
    console.warn("[AMZ] chrome.storage indisponivel, seguindo sem affiliate_id");
  }
  
  var MAPA_CATEGORIAS = {
    "beleza": "Beleza",
    "perfumes": "Beleza",
    "maquiagem": "Beleza",
    "cabelos": "Beleza",
    "skincare": "Beleza",
    "cosmeticos": "Beleza",
    "higiene": "Cuidados Pessoais e Limpeza",
    "limpeza": "Cuidados Pessoais e Limpeza",
    "saude": "Cuidados Pessoais e Limpeza",
    "eletronicos": "Eletronicos e Celulares",
    "celulares": "Eletronicos e Celulares",
    "smartphones": "Eletronicos e Celulares",
    "tablets": "Eletronicos e Celulares",
    "fones": "Eletronicos e Celulares",
    "smartwatch": "Eletronicos e Celulares",
    "cameras": "Eletronicos e Celulares",
    "audio": "Eletronicos e Celulares",
    "tv": "Eletronicos e Celulares",
    "televisores": "Eletronicos e Celulares",
    "informatica": "Informatica",
    "computadores": "Informatica",
    "notebooks": "Informatica",
    "laptops": "Informatica",
    "perifericos": "Informatica",
    "teclados": "Informatica",
    "mouses": "Informatica",
    "monitores": "Informatica",
    "impressoras": "Informatica",
    "games": "Video Games",
    "jogos": "Video Games",
    "playstation": "Video Games",
    "xbox": "Video Games",
    "nintendo": "Video Games",
    "console": "Video Games",
    "casa": "Casa",
    "decoracao": "Casa",
    "organizacao": "Casa",
    "iluminacao": "Casa",
    "cama": "Casa",
    "banho": "Casa",
    "tapetes": "Casa",
    "cortinas": "Casa",
    "cozinha": "Cozinha",
    "utensilios": "Cozinha",
    "panelas": "Cozinha",
    "talheres": "Cozinha",
    "copos": "Cozinha",
    "pratos": "Cozinha",
    "eletrodomesticos": "Eletrodomesticos",
    "geladeiras": "Eletrodomesticos",
    "fogoes": "Eletrodomesticos",
    "microondas": "Eletrodomesticos",
    "lavadoras": "Eletrodomesticos",
    "aspiradores": "Eletrodomesticos",
    "cafeteiras": "Eletrodomesticos",
    "liquidificadores": "Eletrodomesticos",
    "fritadeiras": "Eletrodomesticos",
    "airfryer": "Eletrodomesticos",
    "moveis": "Moveis",
    "sofas": "Moveis",
    "mesas": "Moveis",
    "cadeiras": "Moveis",
    "estantes": "Moveis",
    "armarios": "Moveis",
    "colchoes": "Moveis",
    "moda": "Moda",
    "roupas": "Moda",
    "calcados": "Moda",
    "sapatos": "Moda",
    "tenis": "Moda",
    "bolsas": "Moda",
    "relogios": "Moda",
    "joias": "Moda",
    "bijuterias": "Moda",
    "oculos": "Moda",
    "lingerie": "Moda",
    "bebes": "Bebes",
    "bebe": "Bebes",
    "maternidade": "Bebes",
    "fraldas": "Bebes",
    "mamadeiras": "Bebes",
    "brinquedos": "Brinquedos e Jogos",
    "bonecas": "Brinquedos e Jogos",
    "carrinhos": "Brinquedos e Jogos",
    "lego": "Brinquedos e Jogos",
    "pelucias": "Brinquedos e Jogos",
    "esportes": "Esportes e Aventura",
    "fitness": "Esportes e Aventura",
    "academia": "Esportes e Aventura",
    "futebol": "Esportes e Aventura",
    "ciclismo": "Esportes e Aventura",
    "camping": "Esportes e Aventura",
    "automotivo": "Automotivo",
    "carros": "Automotivo",
    "motos": "Automotivo",
    "pneus": "Automotivo",
    "pet": "Pet Shop",
    "animais": "Pet Shop",
    "cachorros": "Pet Shop",
    "gatos": "Pet Shop",
    "racao": "Pet Shop",
    "ferramentas": "Ferramentas e Construcao",
    "construcao": "Construcao",
    "jardim": "Jardim e Piscina",
    "piscina": "Jardim e Piscina",
    "jardinagem": "Jardim e Piscina",
    "plantas": "Jardim e Piscina",
    "alimentos": "Alimentos e Bebidas",
    "bebidas": "Alimentos e Bebidas",
    "mercearia": "Alimentos e Bebidas",
    "livros": "Livros",
    "ebooks": "eBooks",
    "papelaria": "Papelaria e Escritorio",
    "escritorio": "Papelaria e Escritorio",
    "escolar": "Papelaria e Escritorio"
  };
  
  var KEYWORDS_CATEGORIA = {
    "Eletronicos e Celulares": ["celular", "smartphone", "iphone", "samsung", "xiaomi", "fone", "earbuds", "airpods", "carregador", "cabo usb", "powerbank", "smartwatch", "tablet", "ipad", "caixa de som", "bluetooth"],
    "Informatica": ["notebook", "laptop", "computador", "pc gamer", "teclado", "mouse", "monitor", "webcam", "pendrive", "ssd", "hd externo", "impressora", "roteador"],
    "Video Games": ["playstation", "ps4", "ps5", "xbox", "nintendo", "switch", "controle gamer", "joystick", "headset gamer"],
    "Beleza": ["maquiagem", "batom", "base", "rimel", "sombra", "perfume", "hidratante", "shampoo", "condicionador", "creme", "serum", "skincare"],
    "Moda": ["vestido", "camisa", "camiseta", "calca", "short", "saia", "blusa", "casaco", "jaqueta", "tenis", "sapato", "sandalia", "bolsa", "mochila", "relogio", "oculos", "brinco", "colar"],
    "Casa": ["almofada", "cortina", "tapete", "quadro", "vaso", "abajur", "luminaria", "organizador", "toalha", "lencol", "cobertor", "edredom"],
    "Cozinha": ["panela", "frigideira", "prato", "copo", "talher", "faca", "tabua", "forma", "assadeira", "garrafa"],
    "Eletrodomesticos": ["geladeira", "fogao", "microondas", "air fryer", "fritadeira", "liquidificador", "batedeira", "cafeteira", "aspirador", "ventilador", "ar condicionado", "secador", "prancha"],
    "Bebes": ["fralda", "mamadeira", "chupeta", "carrinho bebe", "berco", "body", "macacao bebe", "babador"],
    "Brinquedos e Jogos": ["boneca", "carrinho", "lego", "puzzle", "quebra-cabeca", "pelucia", "brinquedo", "boneco", "nerf"],
    "Pet Shop": ["racao", "petisco", "coleira", "comedouro", "cama pet", "cachorro", "gato", "areia gato"],
    "Esportes e Aventura": ["bola", "academia", "haltere", "yoga", "bicicleta", "patins", "luva"],
    "Automotivo": ["carro", "moto", "pneu", "tapete carro", "suporte celular carro"],
    "Alimentos e Bebidas": ["chocolate", "cafe", "biscoito", "whey", "vitamina", "suplemento", "cha"],
    "Livros": ["livro", "manga", "revista"],
    "Papelaria e Escritorio": ["caderno", "caneta", "lapis", "agenda", "post-it", "grampeador", "estojo"],
    "Cuidados Pessoais e Limpeza": ["sabonete", "desodorante", "escova de dente", "papel higienico", "detergente", "sabao"],
    "Moveis": ["sofa", "mesa", "cadeira", "estante", "rack", "guarda-roupa", "escrivaninha"],
    "Jardim e Piscina": ["mangueira", "regador", "vaso planta", "boia", "piscina", "churrasqueira"],
    "Ferramentas e Construcao": ["furadeira", "parafusadeira", "martelo", "chave fenda", "alicate"]
  };
  
  function detectarTipoPagina() {
    var url = window.location.href;
    var hostname = window.location.hostname;
    
    if (hostname.indexOf("affiliate.shopee") !== -1) {
      return { tipo: "afiliado", nome: "Painel de Afiliados" };
    }
    
    if (hostname.indexOf("shopee.com.br") !== -1) {
      if (url.indexOf("/oficial/") !== -1 || url.indexOf("-cat.") !== -1) {
        return { tipo: "categoria", nome: "Categoria / Loja Oficial" };
      }
      if (url.indexOf("/search") !== -1) {
        return { tipo: "busca", nome: "Resultado de Busca" };
      }
      if (url.indexOf("-i.") !== -1 || url.indexOf("/product/") !== -1) {
        return { tipo: "produto", nome: "Produto Individual" };
      }
      return { tipo: "shopee", nome: "Pagina Shopee" };
    }
    
    return { tipo: "desconhecido", nome: "Pagina nao suportada" };
  }
  
  function removerAcentos(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }
  
  function detectarCategoria() {
    var url = window.location.href.toLowerCase();
    var pathname = window.location.pathname.toLowerCase();
    var pageTitle = (document.title || "").toLowerCase();
    
    var textoAnalise = removerAcentos(url + " " + pathname + " " + pageTitle);
    
    for (var slug in MAPA_CATEGORIAS) {
      if (textoAnalise.indexOf(slug) !== -1) {
        console.log("Categoria detectada: " + MAPA_CATEGORIAS[slug]);
        return MAPA_CATEGORIAS[slug];
      }
    }
    
    return null;
  }
  
  function detectarCategoriaProduto(nome) {
    if (!nome) return null;
    
    var nomeLower = removerAcentos(nome.toLowerCase());
    
    for (var categoria in KEYWORDS_CATEGORIA) {
      var keywords = KEYWORDS_CATEGORIA[categoria];
      for (var i = 0; i < keywords.length; i++) {
        var kw = removerAcentos(keywords[i]);
        if (nomeLower.indexOf(kw) !== -1) {
          return categoria;
        }
      }
    }
    
    return null;
  }
  
  function gerarLinkAfiliado(urlOriginal) {
    // Se nao ha affiliate_id configurado, retorna link limpo da Shopee
    // (comportamento ideal para seller/prestador que nao e afiliado)
    if (!AFFILIATE_ID) {
      return urlOriginal.split("?")[0];
    }

    if (urlOriginal.indexOf("affiliate_id") !== -1 || urlOriginal.indexOf("an_redir") !== -1) {
      return urlOriginal;
    }

    var urlLimpa = urlOriginal.split("?")[0];
    var urlEncoded = encodeURIComponent(urlLimpa);

    return "https://s.shopee.com.br/an_redir?origin_link=" + urlEncoded + "&affiliate_id=" + AFFILIATE_ID;
  }
  
  function forcarCarregamentoImagens() {
    var imgs = document.querySelectorAll("img[data-src]");
    for (var i = 0; i < imgs.length; i++) {
      var img = imgs[i];
      if (img.dataset.src && img.src.indexOf("susercontent") === -1) {
        img.src = img.dataset.src;
      }
    }
    window.dispatchEvent(new Event("scroll"));
  }
  
  function parsePreco(texto) {
    if (!texto) return 0;
    var limpo = texto.replace(/R\$/gi, "").replace(/\s/g, "").trim();
    if (limpo.indexOf(",") !== -1) {
      limpo = limpo.replace(/\./g, "").replace(",", ".");
    }
    var num = parseFloat(limpo);
    return isNaN(num) || num <= 0 ? 0 : Math.round(num * 100) / 100;
  }
  
  function extrairPreco(card) {
    var precoSelectors = [
      "[data-sqe=\"price\"]",
      ".shopee-item-card__current-price",
      "span[class*=\"ooOxS\"]",
      "span[class*=\"vioxXd\"]",
      "span[class*=\"price\"]",
      "div[class*=\"price\"]"
    ];
    
    for (var i = 0; i < precoSelectors.length; i++) {
      var elements = card.querySelectorAll(precoSelectors[i]);
      for (var j = 0; j < elements.length; j++) {
        var texto = elements[j].innerText || elements[j].textContent || "";
        if (texto.indexOf("R$") !== -1 || /^\s*\d+[.,]\d{2}\s*$/.test(texto.trim())) {
          var preco = parsePreco(texto);
          if (preco > 0 && preco < 100000) {
            return preco;
          }
        }
      }
    }
    
    var allText = card.innerText || "";
    var matches = allText.match(/R\$\s*([\d.]+,\d{2})/g);
    if (matches && matches.length > 0) {
      var menor = Infinity;
      for (var k = 0; k < matches.length; k++) {
        var p = parsePreco(matches[k]);
        if (p > 0 && p < menor) menor = p;
      }
      if (menor < Infinity) return menor;
    }
    
    return 0;
  }
  
  function extrairDadosCard(card, linkEl, categoriaPagina) {
    var url = linkEl.href || "";
    if (url.indexOf("shopee.com.br") === -1) {
      url = "https://shopee.com.br" + url;
    }
    url = url.split("?")[0];
    
    var linkAfiliado = gerarLinkAfiliado(url);
    
    var nome = "";
    var nomeSelectors = ["[data-sqe=\"name\"]", "div[class*=\"name\"]", "span[class*=\"name\"]", ".line-clamp-2", "img[alt]"];
    for (var i = 0; i < nomeSelectors.length; i++) {
      var el = card.querySelector(nomeSelectors[i]);
      if (el) {
        if (nomeSelectors[i] === "img[alt]") {
          nome = el.alt || "";
        } else {
          nome = (el.innerText || el.textContent || "").trim();
        }
        if (nome && nome.length > 5) break;
      }
    }
    if (!nome) nome = linkEl.title || "";
    if (!nome || nome.length < 5) return null;
    
    var preco = extrairPreco(card);
    
    var categoria = categoriaPagina || detectarCategoriaProduto(nome);
    
    var imagem = "";
    var imgSelectors = ["img[src*=\"susercontent\"]", "img[src*=\"shopee\"]", "img[data-src]", "img[src]"];
    for (var j = 0; j < imgSelectors.length; j++) {
      var imgEl = card.querySelector(imgSelectors[j]);
      if (imgEl) {
        imagem = imgEl.dataset && imgEl.dataset.src ? imgEl.dataset.src : imgEl.src;
        if (imagem && imagem.indexOf("data:") === -1) {
          imagem = imagem.replace(/_tn$/, "").replace(/\?.*$/, "");
          if (imagem.indexOf("//") === 0) imagem = "https:" + imagem;
          break;
        }
      }
    }
    
    console.log("Produto: " + nome.substring(0, 30) + " | R$ " + preco + " | Cat: " + (categoria || "N/A"));
    
    return {
      nome: nome,
      preco: preco,
      imagem: imagem,
      link: linkAfiliado,
      linkOriginal: url,
      marketplace: "Shopee",
      categoria: categoria
    };
  }
  
  function extrairProdutos() {
    console.log("Extraindo produtos...");
    forcarCarregamentoImagens();
    
    var categoriaPagina = detectarCategoria();
    var produtos = [];
    var produtosMap = {};
    
    var cardSelectors = [
      ".shopee-search-item-result__item",
      "[data-sqe=\"item\"]",
      ".col-xs-2-4",
      "a[data-sqe=\"link\"]"
    ];
    
    var cards = [];
    for (var i = 0; i < cardSelectors.length; i++) {
      cards = document.querySelectorAll(cardSelectors[i]);
      if (cards.length > 0) break;
    }
    
    if (cards.length === 0) {
      var links = document.querySelectorAll("a[href*=\"-i.\"]");
      for (var j = 0; j < links.length; j++) {
        var link = links[j];
        var card = link.closest("div[class]") || link.parentElement;
        if (card) {
          var produto = extrairDadosCard(card, link, categoriaPagina);
          if (produto && !produtosMap[produto.link]) {
            produtosMap[produto.link] = true;
            produtos.push(produto);
          }
        }
      }
      return produtos;
    }
    
    for (var k = 0; k < cards.length; k++) {
      var cardItem = cards[k];
      var linkItem = cardItem.querySelector("a[href*=\"-i.\"]") || 
                     cardItem.querySelector("a[href*=\"/product/\"]") ||
                     (cardItem.tagName === "A" ? cardItem : null);
      if (!linkItem) continue;
      
      var produtoItem = extrairDadosCard(cardItem, linkItem, categoriaPagina);
      if (produtoItem && !produtosMap[produtoItem.link]) {
        produtosMap[produtoItem.link] = true;
        produtos.push(produtoItem);
      }
    }
    
    console.log("Total: " + produtos.length + " produtos");
    return produtos;
  }
  
  function scrollEExtrair(quantidadeDesejada) {
    return new Promise(function(resolve) {
      console.log("Meta: " + quantidadeDesejada + " produtos");
      
      var todosProdutos = {};
      var produtosIniciais = extrairProdutos();
      for (var i = 0; i < produtosIniciais.length; i++) {
        var p = produtosIniciais[i];
        if (p.link) todosProdutos[p.link] = p;
      }
      
      var total = Object.keys(todosProdutos).length;
      if (total >= quantidadeDesejada) {
        var resultado = [];
        for (var key in todosProdutos) {
          resultado.push(todosProdutos[key]);
          if (resultado.length >= quantidadeDesejada) break;
        }
        resolve(resultado);
        return;
      }
      
      var semNovos = 0;
      var scrolls = 0;
      var maxScrolls = 30;
      var maxSemNovos = 8;
      var ultimoTotal = total;
      
      var interval = setInterval(function() {
        forcarCarregamentoImagens();
        var atuais = extrairProdutos();
        for (var j = 0; j < atuais.length; j++) {
          var prod = atuais[j];
          if (prod.link && !todosProdutos[prod.link]) {
            todosProdutos[prod.link] = prod;
          }
        }
        
        total = Object.keys(todosProdutos).length;
        scrolls++;
        
        if (total > ultimoTotal) {
          semNovos = 0;
        } else {
          semNovos++;
        }
        ultimoTotal = total;
        
        if (total >= quantidadeDesejada || semNovos >= maxSemNovos || scrolls >= maxScrolls) {
          clearInterval(interval);
          window.scrollTo(0, 0);
          var resultadoFinal = [];
          for (var k in todosProdutos) {
            resultadoFinal.push(todosProdutos[k]);
            if (resultadoFinal.length >= quantidadeDesejada) break;
          }
          resolve(resultadoFinal);
          return;
        }
        
        window.scrollBy({ top: window.innerHeight * 0.8, behavior: "auto" });
      }, 800);
    });
  }
  
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log("Acao recebida: " + request.action);
    
    if (request.action === "detectar_tipo") {
      var tipo = detectarTipoPagina();
      var categoria = detectarCategoria();
      sendResponse({ success: true, tipo: tipo.tipo, nome: tipo.nome, categoria: categoria });
      return true;
    }
    
    if (request.action === "extrair_produtos") {
      var quantidade = request.quantidade || 50;
      
      scrollEExtrair(quantidade).then(function(produtos) {
        var comPreco = 0;
        var comCategoria = 0;
        for (var i = 0; i < produtos.length; i++) {
          if (produtos[i].preco > 0) comPreco++;
          if (produtos[i].categoria) comCategoria++;
        }
        console.log("Extraido: " + produtos.length + " | Preco: " + comPreco + " | Categoria: " + comCategoria);
        
        sendResponse({ success: true, produtos: produtos });
      }).catch(function(error) {
        sendResponse({ success: false, produtos: [], error: error.message });
      });
      
      return true;
    }
    
    return true;
  });
  
  console.log("[AMZ] Content script pronto!");
  
})();
