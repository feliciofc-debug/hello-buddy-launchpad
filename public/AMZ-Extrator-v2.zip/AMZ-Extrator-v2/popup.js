let rawContacts = [];
let filteredContacts = [];
let selectedFormat = 'csv-comma';

// ═══ Format selector ═══
document.querySelectorAll('.fmt').forEach(opt => {
  opt.addEventListener('click', () => {
    document.querySelectorAll('.fmt').forEach(o => o.classList.remove('active'));
    opt.classList.add('active');
    selectedFormat = opt.dataset.format;
  });
});

// ═══ DDD filter toggle ═══
document.getElementById('filterDDD').addEventListener('change', function() {
  document.getElementById('dddWrap').classList.toggle('show', this.checked);
  if (rawContacts.length > 0) applyFilters();
});

// Re-apply filters when toggles change
['filterBR', 'filterDupes', 'filterPhone', 'filterDDD'].forEach(id => {
  document.getElementById(id).addEventListener('change', () => {
    if (rawContacts.length > 0) applyFilters();
  });
});
document.getElementById('dddInput').addEventListener('input', () => {
  if (rawContacts.length > 0) applyFilters();
});

// ═══ Check connection ═══
async function checkConnection() {
  const dot = document.getElementById('statusDot');
  const label = document.getElementById('statusText');
  const card = document.getElementById('statusCard');
  const btn = document.getElementById('btnExtract');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab && tab.url && tab.url.includes('web.whatsapp.com')) {
      dot.classList.add('on');
      label.classList.add('on');
      label.textContent = 'WhatsApp Web conectado';
      card.classList.add('ok');
      btn.disabled = false;

      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const el = document.querySelector('header span[title]');
            return el ? el.getAttribute('title') : null;
          }
        });
        if (results?.[0]?.result) {
          document.getElementById('groupBox').style.display = 'block';
          document.getElementById('groupName').textContent = results[0].result;
        }
      } catch(e) {}
    } else {
      label.textContent = 'Abra o WhatsApp Web primeiro';
      btn.disabled = true;
    }
  } catch(e) {
    label.textContent = 'Erro ao verificar conexão';
    btn.disabled = true;
  }
}

// ═══ Phone utilities ═══
function normalizePhone(phone) {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');
  // Ensure starts with +
  if (!cleaned.startsWith('+') && cleaned.length >= 10) {
    // If starts with 55 and has 12-13 digits, it's BR
    if (cleaned.startsWith('55') && cleaned.length >= 12) {
      cleaned = '+' + cleaned;
    }
    // If has 10-11 digits (no country code), assume BR
    else if (cleaned.length >= 10 && cleaned.length <= 11) {
      cleaned = '+55' + cleaned;
    }
    else {
      cleaned = '+' + cleaned;
    }
  }
  return cleaned;
}

function isBRNumber(phone) {
  const n = normalizePhone(phone);
  return n.startsWith('+55');
}

function getDDD(phone) {
  const n = normalizePhone(phone);
  if (n.startsWith('+55') && n.length >= 5) {
    return n.substring(3, 5);
  }
  return '';
}

function formatBRPhone(phone) {
  const n = normalizePhone(phone);
  if (n.startsWith('+55') && n.length >= 13) {
    // +55 XX XXXXX-XXXX
    return `+55 ${n.slice(3,5)} ${n.slice(5,10)}-${n.slice(10)}`;
  }
  return n;
}

// ═══ Apply filters ═══
function applyFilters() {
  const brOnly = document.getElementById('filterBR').checked;
  const dedup = document.getElementById('filterDupes').checked;
  const phoneOnly = document.getElementById('filterPhone').checked;
  const dddFilter = document.getElementById('filterDDD').checked;
  const dddInput = document.getElementById('dddInput').value;

  let allowedDDDs = [];
  if (dddFilter && dddInput.trim()) {
    allowedDDDs = dddInput.split(',').map(d => d.trim().replace(/\D/g, '')).filter(d => d.length === 2);
  }

  let contacts = [...rawContacts];
  let totalBefore = contacts.length;
  let brCount = 0;
  let dupesRemoved = 0;

  // Normalize phones
  contacts = contacts.map(c => ({
    ...c,
    phone: normalizePhone(c.phone),
    isBR: isBRNumber(c.phone)
  }));

  // Count BR
  brCount = contacts.filter(c => c.isBR).length;

  // Filter: phone only
  if (phoneOnly) {
    contacts = contacts.filter(c => c.phone && c.phone.length >= 8);
  }

  // Filter: BR only
  if (brOnly) {
    contacts = contacts.filter(c => c.isBR);
  }

  // Filter: DDD
  if (dddFilter && allowedDDDs.length > 0) {
    contacts = contacts.filter(c => {
      const ddd = getDDD(c.phone);
      return allowedDDDs.includes(ddd);
    });
  }

  // Dedup
  if (dedup) {
    const seen = new Set();
    const unique = [];
    for (const c of contacts) {
      const key = c.phone || c.name;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(c);
      } else {
        dupesRemoved++;
      }
    }
    contacts = unique;
  }

  filteredContacts = contacts;
  displayResults(contacts, totalBefore, brCount, dupesRemoved);
}

// ═══ Extract ═══
document.getElementById('btnExtract').addEventListener('click', async () => {
  const loading = document.getElementById('loading');
  const errorMsg = document.getElementById('errorMsg');
  const warnMsg = document.getElementById('warnMsg');
  const results = document.getElementById('results');

  loading.classList.add('show');
  errorMsg.classList.remove('show');
  warnMsg.classList.remove('show');
  results.classList.remove('show');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    const response = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractContactsFromPage
    });

    loading.classList.remove('show');

    if (response?.[0]?.result) {
      const data = response[0].result;

      if (data.error) {
        showError(data.error);
        return;
      }

      if (data.contacts?.length > 0) {
        rawContacts = data.contacts;

        if (data.warning) {
          showWarning(data.warning);
        }

        applyFilters();
      } else {
        showError('Nenhum contato encontrado. Abra os detalhes do grupo (clique no nome) e role a lista de membros para carregar todos.');
      }
    } else {
      showError('Não foi possível extrair. Verifique se está em um grupo no WhatsApp Web.');
    }
  } catch(e) {
    loading.classList.remove('show');
    showError('Erro: ' + e.message);
  }
});

// ═══ Extraction (runs inside WhatsApp Web) ═══
function extractContactsFromPage() {
  const contacts = [];
  const seen = new Set();
  let warning = '';

  const skipWords = [
    'pesquisar', 'nova conversa', 'mais opções', 'status', 'canais',
    'comunidades', 'silenciado', 'arquivadas', 'favoritas', 'grupos',
    'mídias', 'sair do grupo', 'denunciar', 'adicionar participante',
    'convidar via link', 'você', 'admin do grupo', 'mensagens temporárias',
    'criptografia', 'configurações', 'privacidade', 'segurança',
    'descrição do grupo', 'links', 'docs', 'silenciar notificações',
    'mensagens favoritas', 'sair', 'estrela', 'adicionar', 'convidar',
    'participantes', 'criou este grupo', 'adicionou', 'saiu', 'removeu',
    'alterou', 'fixada', 'enquete'
  ];

  function shouldSkip(text) {
    const t = text.toLowerCase().trim();
    if (t.length < 3 || t.length > 60) return true;
    if (skipWords.some(w => t.includes(w))) return true;
    if (t.includes('http') || t.includes(':') && !t.includes('+')) return true;
    return false;
  }

  function isPhone(text) {
    const cleaned = text.replace(/[\s\-\(\)]/g, '');
    return /^\+?\d{8,15}$/.test(cleaned);
  }

  function addContact(text) {
    if (!text || seen.has(text)) return;
    if (shouldSkip(text)) return;
    seen.add(text);

    const phone = isPhone(text);
    contacts.push({
      name: phone ? '' : text,
      phone: phone ? text.replace(/[^\d+]/g, '') : ''
    });
  }

  // Strategy 1: Group info panel members
  const selectors = [
    '[data-testid="cell-frame-container"] span[title]',
    '[role="listitem"] span[title]',
    'div[data-animate-drawer-content] span[title]',
    '[data-testid="group-info-participants-section"] span[title]',
  ];

  for (const sel of selectors) {
    document.querySelectorAll(sel).forEach(el => {
      addContact((el.getAttribute('title') || el.textContent || '').trim());
    });
  }

  // Strategy 2: Phone numbers in spans
  document.querySelectorAll('span[title], span[dir="auto"]').forEach(el => {
    const text = (el.getAttribute('title') || el.textContent || '').trim();
    if (isPhone(text)) addContact(text);
  });

  // Strategy 3: Drawer panel
  const drawer = document.querySelector('[data-animate-drawer-content]') ||
                  document.querySelector('[data-testid="drawer-right"]');
  if (drawer) {
    drawer.querySelectorAll('span[title], span[dir]').forEach(el => {
      addContact((el.getAttribute('title') || el.textContent || '').trim());
    });
  }

  // Check if we're in a group
  if (contacts.length === 0) {
    const isGroup = document.querySelector('[data-testid="group-info-participants-section"]') ||
                    document.querySelector('[data-icon="group"]');
    if (!isGroup) {
      return { error: 'Não parece ser um grupo. Abra um grupo, clique no nome dele no topo para ver os membros.' };
    }
    return { error: 'Nenhum membro encontrado. Clique no nome do grupo para abrir detalhes e role a lista de membros.' };
  }

  // Warn about contacts without phone
  const noPhone = contacts.filter(c => !c.phone).length;
  if (noPhone > 0) {
    warning = `${noPhone} contato(s) sem número visível (são contatos salvos na agenda — o WhatsApp não mostra o número deles no HTML).`;
  }

  return { contacts, warning };
}

// ═══ Display results ═══
function displayResults(contacts, totalRaw, brCount, dupes) {
  document.getElementById('results').classList.add('show');
  document.getElementById('statTotal').textContent = contacts.length;
  document.getElementById('statBR').textContent = brCount;
  document.getElementById('statDupes').textContent = dupes;

  const list = document.getElementById('contactList');
  list.innerHTML = '';

  contacts.forEach(c => {
    const div = document.createElement('div');
    div.className = 'contact-item';
    const isBR = c.isBR;
    const tag = c.phone ? (isBR ? '<span class="tag tag-br">BR</span>' : '<span class="tag tag-int">INT</span>') : '';
    const displayPhone = isBR ? formatBRPhone(c.phone) : (c.phone || '—');
    div.innerHTML = `
      <span class="contact-name">${c.name || '(Sem nome)'}${tag}</span>
      <span class="contact-phone">${displayPhone}</span>
    `;
    list.appendChild(div);
  });
}

// ═══ Show messages ═══
function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg;
  el.classList.add('show');
}
function showWarning(msg) {
  const el = document.getElementById('warnMsg');
  el.textContent = msg;
  el.classList.add('show');
}

// ═══ Download ═══
document.getElementById('btnDownload').addEventListener('click', () => {
  if (filteredContacts.length === 0) return;

  let content = '';
  let filename = '';
  let mime = 'text/csv';

  const group = document.getElementById('groupName').textContent || 'contatos';
  const safe = group.replace(/[^a-zA-Z0-9\u00C0-\u024F]/g, '_').substring(0, 30);
  const date = new Date().toISOString().slice(0, 10);

  if (selectedFormat === 'csv-comma') {
    content = 'Nome,Telefone\n';
    filteredContacts.forEach(c => {
      content += `${(c.name || '').replace(/,/g, ' ')},${c.phone || ''}\n`;
    });
    filename = `${safe}_${date}.csv`;
  } else if (selectedFormat === 'csv-semicolon') {
    content = 'Nome;Telefone\n';
    filteredContacts.forEach(c => {
      content += `${(c.name || '').replace(/;/g, ' ')};${c.phone || ''}\n`;
    });
    filename = `${safe}_${date}.csv`;
  } else {
    filteredContacts.forEach(c => {
      if (c.phone) content += `${c.phone}\n`;
      else if (c.name) content += `${c.name}\n`;
    });
    filename = `${safe}_${date}.txt`;
    mime = 'text/plain';
  }

  const blob = new Blob(['\uFEFF' + content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
});

// ═══ Copy phones to clipboard ═══
document.getElementById('btnCopy').addEventListener('click', async () => {
  if (filteredContacts.length === 0) return;

  const phones = filteredContacts
    .filter(c => c.phone)
    .map(c => c.phone)
    .join('\n');

  try {
    await navigator.clipboard.writeText(phones);
    const btn = document.getElementById('btnCopy');
    const original = btn.innerHTML;
    btn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
      Copiado!
    `;
    btn.style.borderColor = '#22c55e';
    btn.style.color = '#16a34a';
    setTimeout(() => {
      btn.innerHTML = original;
      btn.style.borderColor = '';
      btn.style.color = '';
    }, 2000);
  } catch(e) {
    showError('Não foi possível copiar. Tente baixar o arquivo.');
  }
});

// ═══ Init ═══
checkConnection();
