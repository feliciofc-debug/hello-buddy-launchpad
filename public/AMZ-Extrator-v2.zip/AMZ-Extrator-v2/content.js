// AMZ Ofertas Extrator v2 — Content Script
(function() {
  if (document.getElementById('amz-ext-badge')) return;
  const el = document.createElement('div');
  el.id = 'amz-ext-badge';
  el.innerHTML = '<div style="position:fixed;bottom:20px;right:20px;background:linear-gradient(135deg,#7e22ce,#a855f7);color:#fff;padding:7px 16px;border-radius:24px;font-family:-apple-system,sans-serif;font-size:12px;font-weight:600;z-index:9999;box-shadow:0 4px 14px rgba(126,34,206,0.3);display:flex;align-items:center;gap:6px;opacity:0.9;transition:opacity 0.3s" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.9"><span style="background:#fff;color:#7e22ce;font-weight:800;font-size:10px;padding:2px 6px;border-radius:4px">AMZ</span>Extrator v2 ativo</div>';
  document.body.appendChild(el);
  setTimeout(() => { el.style.transition='opacity 0.6s'; el.style.opacity='0'; setTimeout(()=>el.remove(),600); }, 4000);
})();
